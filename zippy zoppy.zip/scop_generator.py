import datetime
import math

# --- compression table (5-bit to ASCII) ---
ENCODE_TABLE = "0123456789abcdefghijklmnopqrstuv"
DECODE_TABLE = {ch: i for i, ch in enumerate(ENCODE_TABLE)}

def float_to_bin(value, pm, n_bits):
    """Convert a float to (sign, binary string or compressed char)."""
    sign = 1 if value >= 0 else 0
    vmax = (2**n_bits - 1)
    mag = int(abs(value) / pm * vmax)
    return sign, mag

def encode_value(mag, n_bits, comp):
    """Encode magnitude as binary or compressed string."""
    if comp:
        # Split into 5-bit chunks
        chunks = []
        for i in range(n_bits // 5):
            chunk = (mag >> (5 * (n_bits // 5 - 1 - i))) & 0b11111
            chunks.append(ENCODE_TABLE[chunk])
        return "".join(chunks)
    else:
        return bin(mag)[2:].zfill(n_bits)

def generate_scop(config_file, data_file, output_file):
    # --- read config ---
    with open(config_file, "r") as f:
        config = {}
        for line in f:
            if "=" in line:
                k, v = line.strip().split("=", 1)
                config[k.strip()] = v.strip()

    author = config.get("author", "unknown")
    file_id = config.get("ID", "noID")
    comp = int(config.get("COMP", "0"))
    pm_val, pm_unit = config.get("pm", "1E0 V").split()
    pm = float(pm_val.replace("E", "e"))
    delta_t_val, delta_t_unit = config.get("delta t", "1E-3 s").split()
    delta_t = float(delta_t_val.replace("E", "e"))
    n_bits = int(config.get("N bits per sample", "8"))
    n_chl = int(config.get("N chl", "1"))
    channels = [config.get(f"CHL{i+1}", f"CHL{i+1}") for i in range(n_chl)]

    # --- read data file ---
    with open(data_file, "r") as f:
        rows = [list(map(float, line.split())) for line in f if line.strip()]

    n_samples = len(rows)

    # --- write scop file ---
    with open(output_file, "w") as f:
        f.write("SCOP\nVOLTAGE\n")
        f.write(f"author = {author}\n")
        f.write("CRTdate = " + datetime.datetime.now().strftime("%y%m%d%H%M%S") + "\n")
        f.write(f"ID = {file_id}\n")
        f.write(f"COMP = {comp}\n")
        f.write(f"pm = {pm_val} {pm_unit}\n")
        f.write(f"delta t = {delta_t_val} {delta_t_unit}\n")
        f.write(f"N sample = {n_samples}\n")
        f.write(f"N bits per sample = {n_bits}\n")
        f.write(f"N chl = {n_chl}\n\n")

        f.write("CHLTBL\n")
        for i, ch in enumerate(channels, 1):
            f.write(f"CHL{i} = {ch}\n")
        f.write("\nDATA\n")

        for ch_index, ch in enumerate(channels):
            f.write(f"CHL{ch_index+1}\n")
            for i, row in enumerate(rows, 1):
                sign, mag = float_to_bin(row[ch_index], pm, n_bits)
                enc = encode_value(mag, n_bits, comp)
                f.write(f"{i}: {sign},{enc}\n")
            f.write(f"ENDCHL{ch_index+1}\n\n")

        f.write("END\n")

    print(f"✅ SCOP file written to {output_file}")
