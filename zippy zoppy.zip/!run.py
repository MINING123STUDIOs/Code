generate_scop("config.txt", "values.txt", "output.scop")
