def read_scop(filename):
    """
    Reads a .scop file and returns metadata and channel data.
    
    Returns:
        meta: dict of header metadata
        data: dict[channel_name] -> list of float voltages
    """
    ENCODE_TABLE = "0123456789abcdefghijklmnopqrstuv"
    DECODE_TABLE = {ch: i for i, ch in enumerate(ENCODE_TABLE)}

    def decode_value(enc, n_bits, comp):
        """Decode a compressed or uncompressed value to integer."""
        if comp:
            mag = 0
            for ch in enc.strip():
                mag = (mag << 5) | DECODE_TABLE[ch]
            return mag
        else:
            return int(enc, 2)

    with open(filename, "r") as f:
        lines = [line.strip() for line in f if line.strip()]

    # --- Parse metadata header ---
    meta = {}
    i = 0
    while i < len(lines) and not lines[i].startswith("CHLTBL"):
        if "=" in lines[i]:
            k, v = lines[i].split("=", 1)
            meta[k.strip()] = v.strip()
        i += 1

    # Read essential parameters
    comp = int(meta.get("COMP", "0"))
    n_bits = int(meta.get("N bits per sample", "8"))
    pm_val, _ = meta.get("pm", "1E0 V").split()
    pm = float(pm_val.replace("E", "e"))

    # --- Parse channel table ---
    channels = {}
    while i < len(lines) and not lines[i].startswith("DATA"):
        if "=" in lines[i]:
            k, v = lines[i].split("=", 1)
            channels[k.strip()] = v.strip()
        i += 1

    # --- Parse data blocks ---
    data = {v: [] for v in channels.values()}
    current_channel = None

    while i < len(lines):
        line = lines[i]
        if line.startswith("CHL") and not line.startswith("CHLTBL"):
            current_channel = channels.get(line, None)
        elif line.startswith("ENDCHL"):
            current_channel = None
        elif ":" in line and current_channel:
            try:
                idx, rest = line.split(":", 1)
                sign_str, enc = rest.split(",", 1)
                sign = int(sign_str)
                mag = decode_value(enc.strip(), n_bits, comp)
                vmax = (2**n_bits - 1)
                # Voltage calculation
                val = ((1 if sign == 1 else -1) * pm * mag / vmax)
                data[current_channel].append(val)
            except Exception as e:
                print(f"Warning: could not parse line: {line} -> {e}")
        i += 1

    return meta, data
