# read_scop_run.py
from scop_reader import read_scop
import csv

INPUT = input("Enter the path of the SCOP file to read: ")
OUTPUT = input("Enter the path for the CSV output file (default: decoded.csv): ")

if not OUTPUT:
    OUTPUT = "decoded.csv"

meta, data = read_scop(INPUT)

channels = list(data.keys())
n_samples = len(next(iter(data.values())))

with open(OUTPUT, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(channels)
    for i in range(n_samples):
        row = [data[ch][i] for ch in channels]
        writer.writerow(row)

print(f"✅ SCOP file read and saved as {OUTPUT}")
